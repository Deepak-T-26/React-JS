import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import Viewstory from './Viewstory.jsx'
import Profile from './profile.jsx'

const router =createBrowserRouter(
  [
    {    //used for new page 
      path:'/', //home
      element:<App/>
    },
    {
      path: '/story/:id/:tot',
      element:<Viewstory/>
    },
    {
      path: '/profile',
      element : <Profile/>
    }
  ]
)



createRoot(document.getElementById('root')).render( //clear Strictmode if using router
   /*  <App /> */
   <RouterProvider router={router}/>

)
