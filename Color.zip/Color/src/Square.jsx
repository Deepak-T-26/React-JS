import React from 'react'

function Square({ colorValue, hexValue, isDarkText }) {
  const squareStyle = {
    backgroundColor: colorValue || 'white',
    color: isDarkText ? '#000' : '#FFF', // Text color toggle logic
  }

  return (
    <section
      style={squareStyle}
      className="square"
    >
      <p>{colorValue || 'Empty Value'}</p>
      <p>{hexValue || null}</p>
    </section>
  )
}

Square.defaultProps = {
  colorValue: 'Empty Color Value',
}

export default Square
