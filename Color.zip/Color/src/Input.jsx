import React from 'react'
import colorNames from 'colornames'

function Input({ colorValue, setColorValue, setHexValue, setIsDarkText }) {
  return (
    <form onSubmit={(e) => e.preventDefault()}>
      <label htmlFor="colorInput">Add Color Name:</label>
      <input
        className="Text"
        id="colorInput"
        type="text"
        autoFocus
        placeholder="Add Color Name"
        required
        value={colorValue}
        onChange={(e) => {
          const newColor = e.target.value
          setColorValue(newColor)

          // Convert color to hex or fallback to white
          const hexValue = colorNames(newColor) || '#FFFFFF' // ✅ Fixed fallback
          setHexValue(hexValue)
        }}
      />
      <button
          type="button"
          onClick={() => {
          console.log('Button clicked!') // Check if button click works
          setIsDarkText((prev) => {
          /* console.log('Previous value:', prev) */ // See the previous state
          return !prev
    })
  }}
>
  Toggle Text Color
</button>

    </form>
  )
}

export default Input
